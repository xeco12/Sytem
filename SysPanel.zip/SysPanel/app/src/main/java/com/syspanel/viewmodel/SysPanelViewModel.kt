package com.syspanel.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.syspanel.data.AppPermissionInfo
import com.syspanel.data.BatteryInfo
import com.syspanel.data.MemoryInfo
import com.syspanel.data.SystemDataRepository
import com.syspanel.data.SystemOverview
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class UiState<T>(
    val data: T? = null,
    val isLoading: Boolean = false,
    val error: String? = null
)

class SysPanelViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = SystemDataRepository(application)

    private val _battery = MutableStateFlow(UiState<BatteryInfo>(isLoading = true))
    val battery: StateFlow<UiState<BatteryInfo>> = _battery.asStateFlow()

    private val _memory = MutableStateFlow(UiState<MemoryInfo>(isLoading = true))
    val memory: StateFlow<UiState<MemoryInfo>> = _memory.asStateFlow()

    private val _permissions = MutableStateFlow(UiState<List<AppPermissionInfo>>(isLoading = true))
    val permissions: StateFlow<UiState<List<AppPermissionInfo>>> = _permissions.asStateFlow()

    private val _overview = MutableStateFlow(UiState<SystemOverview>(isLoading = true))
    val overview: StateFlow<UiState<SystemOverview>> = _overview.asStateFlow()

    private val _showSystemApps = MutableStateFlow(false)
    val showSystemApps: StateFlow<Boolean> = _showSystemApps.asStateFlow()

    init {
        startBatteryFlow()
        startMemoryFlow()
        loadPermissions()
        loadOverview()
    }

    private fun startBatteryFlow() {
        viewModelScope.launch(Dispatchers.IO) {
            repo.batteryFlow(5000L).collect { info ->
                _battery.value = UiState(data = info)
            }
        }
    }

    private fun startMemoryFlow() {
        viewModelScope.launch(Dispatchers.IO) {
            repo.memoryFlow(2000L).collect { info ->
                _memory.value = UiState(data = info)
            }
        }
    }

    fun loadPermissions() {
        viewModelScope.launch(Dispatchers.IO) {
            _permissions.value = UiState(isLoading = true)
            try {
                val data = repo.getAppPermissions()
                _permissions.value = UiState(data = data)
            } catch (e: Exception) {
                _permissions.value = UiState(error = e.message)
            }
        }
    }

    fun loadOverview() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val data = repo.getSystemOverview()
                _overview.value = UiState(data = data)
            } catch (e: Exception) {
                _overview.value = UiState(error = e.message)
            }
        }
    }

    fun toggleSystemApps() {
        _showSystemApps.value = !_showSystemApps.value
    }

    fun formatBytes(bytes: Long) = repo.formatBytes(bytes)
}
