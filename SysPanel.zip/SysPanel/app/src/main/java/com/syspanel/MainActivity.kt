package com.syspanel

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.syspanel.ui.screens.BatteryScreen
import com.syspanel.ui.screens.MemoryScreen
import com.syspanel.ui.screens.OverviewScreen
import com.syspanel.ui.screens.PermissionsScreen
import com.syspanel.ui.theme.SysPanelTheme
import com.syspanel.viewmodel.SysPanelViewModel

sealed class Screen(val route: String, val label: String, val icon: ImageVector) {
    object Overview : Screen("overview", "Genel", Icons.Default.Dashboard)
    object Battery : Screen("battery", "Pil", Icons.Default.BatteryFull)
    object Memory : Screen("memory", "RAM", Icons.Default.Memory)
    object Permissions : Screen("permissions", "İzinler", Icons.Default.Security)
}

val screens = listOf(Screen.Overview, Screen.Battery, Screen.Memory, Screen.Permissions)

class MainActivity : ComponentActivity() {

    private val vm: SysPanelViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SysPanelTheme {
                SysPanelApp(vm = vm)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SysPanelApp(vm: SysPanelViewModel) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDest = navBackStackEntry?.destination

    val currentScreen = screens.find { screen ->
        currentDest?.hierarchy?.any { it.route == screen.route } == true
    } ?: Screen.Overview

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = when (currentScreen) {
                            Screen.Overview -> "SysPanel"
                            Screen.Battery -> "Pil Durumu"
                            Screen.Memory -> "RAM Durumu"
                            Screen.Permissions -> "İzin Denetimi"
                            else -> "SysPanel"
                        },
                        style = MaterialTheme.typography.titleLarge
                    )
                },
                actions = {
                    if (currentScreen == Screen.Permissions) {
                        IconButton(onClick = { vm.loadPermissions() }) {
                            Icon(Icons.Default.Refresh, contentDescription = "Yenile")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar {
                screens.forEach { screen ->
                    val selected = currentDest?.hierarchy?.any { it.route == screen.route } == true
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(screen.icon, contentDescription = screen.label) },
                        label = { Text(screen.label) }
                    )
                }
            }
        },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Overview.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Overview.route) { OverviewScreen(vm) }
            composable(Screen.Battery.route) { BatteryScreen(vm) }
            composable(Screen.Memory.route) { MemoryScreen(vm) }
            composable(Screen.Permissions.route) { PermissionsScreen(vm) }
        }
    }
}
