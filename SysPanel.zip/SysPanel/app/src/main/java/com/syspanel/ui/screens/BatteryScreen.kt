package com.syspanel.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.syspanel.viewmodel.SysPanelViewModel

@Composable
fun BatteryScreen(vm: SysPanelViewModel) {
    val state by vm.battery.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        state.data?.let { battery ->
            // Dairesel pil göstergesi
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val primaryColor = MaterialTheme.colorScheme.primary
                    val surfaceVariant = MaterialTheme.colorScheme.surfaceVariant
                    val batteryColor = when {
                        battery.level > 50 -> primaryColor
                        battery.level > 20 -> Color(0xFFF59E0B)
                        else -> MaterialTheme.colorScheme.error
                    }

                    Box(contentAlignment = Alignment.Center) {
                        Canvas(modifier = Modifier.size(180.dp)) {
                            val strokeWidth = 20.dp.toPx()
                            val radius = (size.minDimension - strokeWidth) / 2
                            val center = Offset(size.width / 2, size.height / 2)

                            // Arka plan halkası
                            drawArc(
                                color = surfaceVariant,
                                startAngle = -225f,
                                sweepAngle = 270f,
                                useCenter = false,
                                topLeft = Offset(center.x - radius, center.y - radius),
                                size = Size(radius * 2, radius * 2),
                                style = Stroke(strokeWidth, cap = StrokeCap.Round)
                            )

                            // Pil seviyesi halkası
                            drawArc(
                                color = batteryColor,
                                startAngle = -225f,
                                sweepAngle = 270f * (battery.level / 100f),
                                useCenter = false,
                                topLeft = Offset(center.x - radius, center.y - radius),
                                size = Size(radius * 2, radius * 2),
                                style = Stroke(strokeWidth, cap = StrokeCap.Round)
                            )
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = when {
                                    battery.plugged != "Bağlı Değil" -> Icons.Default.BatteryChargingFull
                                    battery.level > 80 -> Icons.Default.BatteryFull
                                    battery.level > 50 -> Icons.Default.Battery5Bar
                                    battery.level > 30 -> Icons.Default.Battery3Bar
                                    else -> Icons.Default.Battery1Bar
                                },
                                contentDescription = null,
                                tint = batteryColor,
                                modifier = Modifier.size(32.dp)
                            )
                            Text(
                                text = "%${battery.level}",
                                style = MaterialTheme.typography.displaySmall,
                                fontWeight = FontWeight.Bold,
                                color = batteryColor
                            )
                            Text(
                                text = battery.status,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Detay bilgileri
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("Pil Bilgileri", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)

                    BatteryDetailRow(icon = Icons.Default.Thermostat, label = "Sıcaklık", value = "${battery.temperature}°C",
                        warning = battery.temperature > 40f)
                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                    BatteryDetailRow(icon = Icons.Default.ElectricBolt, label = "Voltaj", value = "${battery.voltage} mV")
                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                    BatteryDetailRow(icon = Icons.Default.HealthAndSafety, label = "Sağlık", value = battery.health,
                        warning = battery.health != "İyi")
                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                    BatteryDetailRow(icon = Icons.Default.Power, label = "Bağlantı", value = battery.plugged)
                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                    BatteryDetailRow(icon = Icons.Default.Science, label = "Teknoloji", value = battery.technology)
                }
            }

            // Sıcaklık uyarısı
            if (battery.temperature > 40f) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null,
                            tint = MaterialTheme.colorScheme.onErrorContainer)
                        Text(
                            "Pil sıcaklığı yüksek (${battery.temperature}°C). Cihazı soğumaya bırakın.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }

        } ?: Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
    }
}

@Composable
fun BatteryDetailRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    warning: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                icon, contentDescription = null,
                modifier = Modifier.size(20.dp),
                tint = if (warning) MaterialTheme.colorScheme.error
                else MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(label, style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(
            value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            color = if (warning) MaterialTheme.colorScheme.error
            else MaterialTheme.colorScheme.onSurface
        )
    }
}
