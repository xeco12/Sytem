package com.syspanel.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.syspanel.viewmodel.SysPanelViewModel

@Composable
fun MemoryScreen(vm: SysPanelViewModel) {
    val state by vm.memory.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        state.data?.let { mem ->
            // RAM dairesel gösterge
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val primaryColor = MaterialTheme.colorScheme.primary
                    val surfaceVariant = MaterialTheme.colorScheme.surfaceVariant
                    val ramColor = when {
                        mem.usedPercent < 60 -> primaryColor
                        mem.usedPercent < 80 -> androidx.compose.ui.graphics.Color(0xFFF59E0B)
                        else -> MaterialTheme.colorScheme.error
                    }

                    Box(contentAlignment = Alignment.Center) {
                        Canvas(modifier = Modifier.size(180.dp)) {
                            val strokeWidth = 20.dp.toPx()
                            val radius = (size.minDimension - strokeWidth) / 2
                            val cx = size.width / 2
                            val cy = size.height / 2

                            drawArc(
                                color = surfaceVariant,
                                startAngle = -90f,
                                sweepAngle = 360f,
                                useCenter = false,
                                topLeft = Offset(cx - radius, cy - radius),
                                size = Size(radius * 2, radius * 2),
                                style = androidx.compose.ui.graphics.drawscope.Stroke(strokeWidth)
                            )
                            drawArc(
                                color = ramColor,
                                startAngle = -90f,
                                sweepAngle = 360f * (mem.usedPercent / 100f),
                                useCenter = false,
                                topLeft = Offset(cx - radius, cy - radius),
                                size = Size(radius * 2, radius * 2),
                                style = androidx.compose.ui.graphics.drawscope.Stroke(
                                    strokeWidth,
                                    cap = androidx.compose.ui.graphics.StrokeCap.Round
                                )
                            )
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Memory, contentDescription = null,
                                tint = ramColor, modifier = Modifier.size(32.dp))
                            Text("%${mem.usedPercent}",
                                style = MaterialTheme.typography.displaySmall,
                                fontWeight = FontWeight.Bold, color = ramColor)
                            Text("RAM Kullanımı",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            // RAM dağılım çubuk grafiği
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("RAM Dağılımı", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)

                    val usedColor = MaterialTheme.colorScheme.primary
                    val freeColor = MaterialTheme.colorScheme.surfaceVariant

                    // Stacked progress bar
                    Box(modifier = Modifier.fillMaxWidth().height(12.dp)) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val usedWidth = size.width * (mem.usedPercent / 100f)
                            drawRoundRect(
                                color = freeColor,
                                size = size,
                                cornerRadius = androidx.compose.ui.geometry.CornerRadius(6.dp.toPx())
                            )
                            drawRoundRect(
                                color = usedColor,
                                size = Size(usedWidth, size.height),
                                cornerRadius = androidx.compose.ui.geometry.CornerRadius(6.dp.toPx())
                            )
                        }
                    }

                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        RamStat(label = "Toplam", value = vm.formatBytes(mem.totalRam),
                            color = MaterialTheme.colorScheme.onSurface)
                        RamStat(label = "Kullanılan", value = vm.formatBytes(mem.usedRam),
                            color = MaterialTheme.colorScheme.primary)
                        RamStat(label = "Boş", value = vm.formatBytes(mem.availableRam),
                            color = MaterialTheme.colorScheme.tertiary)
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)

                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Düşük Bellek Eşiği",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(vm.formatBytes(mem.threshold),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            // Uyarı kartı
            if (mem.usedPercent >= 80) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null,
                            tint = MaterialTheme.colorScheme.onErrorContainer)
                        Text(
                            "RAM kullanımı kritik seviyede (%${mem.usedPercent}). Gereksiz uygulamaları kapatın.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }

        } ?: Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
    }
}

@Composable
fun RamStat(label: String, value: String, color: androidx.compose.ui.graphics.Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold, color = color)
        Text(label, style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
