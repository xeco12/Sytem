package com.syspanel.data

import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Build
import android.os.Process
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

data class BatteryInfo(
    val level: Int,
    val temperature: Float,
    val voltage: Int,
    val status: String,
    val health: String,
    val plugged: String,
    val technology: String,
    val capacity: Long,
    val chargeCounter: Int
)

data class MemoryInfo(
    val totalRam: Long,
    val availableRam: Long,
    val usedRam: Long,
    val usedPercent: Int,
    val threshold: Long
)

data class AppPermissionInfo(
    val packageName: String,
    val appName: String,
    val hasCamera: Boolean,
    val hasMicrophone: Boolean,
    val hasLocation: Boolean,
    val hasContacts: Boolean,
    val hasStorage: Boolean,
    val hasPhone: Boolean,
    val permissionCount: Int,
    val isSystemApp: Boolean
)

data class SystemOverview(
    val batteryLevel: Int,
    val batteryStatus: String,
    val ramUsedPercent: Int,
    val installedApps: Int,
    val dangerousPermApps: Int,
    val androidVersion: String,
    val deviceModel: String
)

class SystemDataRepository(private val context: Context) {

    // ── PİL BİLGİSİ ────────────────────────────────────────────────────────
    fun getBatteryInfo(): BatteryInfo {
        val intentFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val batteryIntent = context.registerReceiver(null, intentFilter)

        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val batteryLevel = if (level != -1 && scale != -1) (level * 100 / scale) else 0

        val temp = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        val temperature = temp / 10f

        val voltage = batteryIntent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0

        val status = when (batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1)) {
            BatteryManager.BATTERY_STATUS_CHARGING -> "Şarj Oluyor"
            BatteryManager.BATTERY_STATUS_DISCHARGING -> "Deşarj Oluyor"
            BatteryManager.BATTERY_STATUS_FULL -> "Dolu"
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Şarj Değil"
            else -> "Bilinmiyor"
        }

        val health = when (batteryIntent?.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "İyi"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Aşırı Sıcak"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Ölü"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Aşırı Voltaj"
            BatteryManager.BATTERY_HEALTH_COLD -> "Soğuk"
            else -> "Bilinmiyor"
        }

        val plugged = when (batteryIntent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1)) {
            BatteryManager.BATTERY_PLUGGED_AC -> "AC Adaptör"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Kablosuz"
            0 -> "Bağlı Değil"
            else -> "Bilinmiyor"
        }

        val technology = batteryIntent?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "Bilinmiyor"

        val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val capacity = batteryManager.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
        val chargeCounter = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)

        return BatteryInfo(
            level = batteryLevel,
            temperature = temperature,
            voltage = voltage,
            status = status,
            health = health,
            plugged = plugged,
            technology = technology,
            capacity = capacity,
            chargeCounter = chargeCounter
        )
    }

    fun batteryFlow(intervalMs: Long = 5000L): Flow<BatteryInfo> = flow {
        while (true) {
            emit(getBatteryInfo())
            delay(intervalMs)
        }
    }

    // ── RAM BİLGİSİ ────────────────────────────────────────────────────────
    fun getMemoryInfo(): MemoryInfo {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)

        val total = memInfo.totalMem
        val available = memInfo.availMem
        val used = total - available
        val percent = ((used.toFloat() / total.toFloat()) * 100).toInt()

        return MemoryInfo(
            totalRam = total,
            availableRam = available,
            usedRam = used,
            usedPercent = percent,
            threshold = memInfo.threshold
        )
    }

    fun memoryFlow(intervalMs: Long = 2000L): Flow<MemoryInfo> = flow {
        while (true) {
            emit(getMemoryInfo())
            delay(intervalMs)
        }
    }

    // ── İZİN DENETİMİ ──────────────────────────────────────────────────────
    fun getAppPermissions(): List<AppPermissionInfo> {
        val pm = context.packageManager
        val packages = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(PackageManager.GET_META_DATA.toLong()))
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledApplications(PackageManager.GET_META_DATA)
        }

        return packages
            .filter { it.packageName != context.packageName }
            .map { appInfo ->
                val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                val appName = pm.getApplicationLabel(appInfo).toString()

                fun hasPerm(perm: String): Boolean = try {
                    pm.checkPermission(perm, appInfo.packageName) == PackageManager.PERMISSION_GRANTED
                } catch (e: Exception) { false }

                val hasCamera = hasPerm(android.Manifest.permission.CAMERA)
                val hasMic = hasPerm(android.Manifest.permission.RECORD_AUDIO)
                val hasLoc = hasPerm(android.Manifest.permission.ACCESS_FINE_LOCATION) ||
                        hasPerm(android.Manifest.permission.ACCESS_COARSE_LOCATION)
                val hasContacts = hasPerm(android.Manifest.permission.READ_CONTACTS)
                val hasStorage = hasPerm(android.Manifest.permission.READ_EXTERNAL_STORAGE) ||
                        hasPerm(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                val hasPhone = hasPerm(android.Manifest.permission.READ_PHONE_STATE)

                val count = listOf(hasCamera, hasMic, hasLoc, hasContacts, hasStorage, hasPhone)
                    .count { it }

                AppPermissionInfo(
                    packageName = appInfo.packageName,
                    appName = appName,
                    hasCamera = hasCamera,
                    hasMicrophone = hasMic,
                    hasLocation = hasLoc,
                    hasContacts = hasContacts,
                    hasStorage = hasStorage,
                    hasPhone = hasPhone,
                    permissionCount = count,
                    isSystemApp = isSystem
                )
            }
            .sortedByDescending { it.permissionCount }
    }

    // ── GENEL BAKIŞ ────────────────────────────────────────────────────────
    fun getSystemOverview(): SystemOverview {
        val battery = getBatteryInfo()
        val memory = getMemoryInfo()
        val apps = try { getAppPermissions() } catch (e: Exception) { emptyList() }
        val dangerousApps = apps.count { it.permissionCount >= 3 && !it.isSystemApp }

        return SystemOverview(
            batteryLevel = battery.level,
            batteryStatus = battery.status,
            ramUsedPercent = memory.usedPercent,
            installedApps = apps.size,
            dangerousPermApps = dangerousApps,
            androidVersion = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            deviceModel = "${Build.MANUFACTURER} ${Build.MODEL}"
        )
    }

    fun formatBytes(bytes: Long): String {
        return when {
            bytes >= 1_073_741_824L -> "%.1f GB".format(bytes / 1_073_741_824.0)
            bytes >= 1_048_576L -> "%.0f MB".format(bytes / 1_048_576.0)
            bytes >= 1_024L -> "%.0f KB".format(bytes / 1_024.0)
            else -> "$bytes B"
        }
    }
}
