package com.syspanel.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.syspanel.data.AppPermissionInfo
import com.syspanel.viewmodel.SysPanelViewModel

@Composable
fun PermissionsScreen(vm: SysPanelViewModel) {
    val state by vm.permissions.collectAsState()
    val showSystem by vm.showSystemApps.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        // Filtre çubuğu
        Surface(tonalElevation = 2.dp) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                state.data?.let { apps ->
                    val filtered = if (showSystem) apps else apps.filter { !it.isSystemApp }
                    Text(
                        "${filtered.size} uygulama",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Sistem uyg.", style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.width(8.dp))
                    Switch(checked = showSystem, onCheckedChange = { vm.toggleSystemApps() })
                }
            }
        }

        when {
            state.isLoading -> Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Uygulamalar taranıyor...", style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            state.error != null -> Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Error, contentDescription = null,
                        tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(state.error ?: "Hata", color = MaterialTheme.colorScheme.error)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(onClick = { vm.loadPermissions() }) { Text("Tekrar Dene") }
                }
            }

            state.data != null -> {
                val filtered = if (showSystem) state.data!! else state.data!!.filter { !it.isSystemApp }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filtered, key = { it.packageName }) { app ->
                        AppPermissionCard(app = app)
                    }
                }
            }
        }
    }
}

@Composable
fun AppPermissionCard(app: AppPermissionInfo) {
    val riskColor = when {
        app.permissionCount >= 4 -> MaterialTheme.colorScheme.errorContainer
        app.permissionCount >= 2 -> MaterialTheme.colorScheme.tertiaryContainer
        else -> MaterialTheme.colorScheme.surface
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = riskColor)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        app.appName,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        app.packageName,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Badge(
                    containerColor = if (app.permissionCount >= 4)
                        MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.outline
                ) {
                    Text("${app.permissionCount} izin", modifier = Modifier.padding(horizontal = 4.dp))
                }
            }

            if (app.permissionCount > 0) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (app.hasCamera) PermChip(Icons.Default.CameraAlt, "Kamera")
                    if (app.hasMicrophone) PermChip(Icons.Default.Mic, "Mikrofon")
                    if (app.hasLocation) PermChip(Icons.Default.LocationOn, "Konum")
                    if (app.hasContacts) PermChip(Icons.Default.Contacts, "Kişiler")
                    if (app.hasStorage) PermChip(Icons.Default.Storage, "Depolama")
                    if (app.hasPhone) PermChip(Icons.Default.Phone, "Telefon")
                }
            }
        }
    }
}

@Composable
fun PermChip(icon: ImageVector, label: String) {
    Surface(
        shape = MaterialTheme.shapes.small,
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Icon(icon, contentDescription = label,
                modifier = Modifier.size(12.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
